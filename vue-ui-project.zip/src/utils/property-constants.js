export const EPropertyRegionValue = {
  KSA: 56,
  INTERNATIONAL: 57,
};
export const EPropertyForValue = {
  SALE: 3,
  RENT: 4,
};
