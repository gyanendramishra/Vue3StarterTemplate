<template>
  <div v-if="loading">
    <h1>{{ title }}</h1>
    <p>
      Your name is : {{ request.fullName }} and email is: {{ request.email }}
    </p>
    <form @submit.prevent="inquire">
      <div class="row">
        <input
          type="text"
          name="fullName"
          placeholder="full name"
          class="input-controll"
          v-model="request.fullName"
        />
      </div>
      <div class="row">
        <input
          type="email"
          name="email"
          placeholder="email"
          class="input-controll"
          v-model="request.email"
        />
      </div>
      <div class="row">
        <input type="submit" value="Inquire" />
      </div>
    </form>
  </div>
  <div v-else>Loading....</div>
</template>
<script>
export default {
  name: "Contact",
  data() {
    return {
      title: "Contact us page",
      loading: false,
      request: {
        fullName: "Gyanendra Mishra",
        email: "gyanendra.kumar@dotsquares.com",
      },
    };
  },
  created() {
    this.loading = true;
    //const x;
    //this.request = x;
  },
  methods: {
    inquire() {
      console.log("Request:", this.request);
    },
  },
};
</script>
<style scoped>
.row {
  display: block;
  width: 100%;
  height: auto;
  margin-bottom: 5px;
}
.input-controll {
  height: 30px;
  border: 1px solid #d4d4d4;
}
</style>
