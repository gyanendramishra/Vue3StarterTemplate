<template>
  <div class="home">
    <h1>{{ $store.state.title }}</h1>
    <input v-model="note" @keypress.enter="handleNoteSave" />
    <NotesList />
    <h1>Another Note Component</h1>
    <NotesList />
  </div>
</template>

<script>
import { ref } from "vue";
import { useStore } from "vuex";
import NotesList from "@/components/NotesList";
export default {
  name: "Home",
  components: {
    NotesList,
  },
  setup() {
    const store = useStore();
    const note = ref("");

    /* Handle note save */
    const handleNoteSave = () => {
      store.dispatch("saveNote", note.value);
      note.value = "";
    };
    // return properties and methods
    return {
      note,
      handleNoteSave,
    };
  },
};
</script>
