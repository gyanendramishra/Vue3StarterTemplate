<template>
  <div :style="{ backgroundColor: themeColor, color: fontColor }">
    <h1>Interpolation</h1>
    <h3>Text</h3>
    <span v-once>This will never change: {{ message }}</span>
    <br />
    <button type="button" v-on:click="changeInterpolation">
      Change message
    </button>
    <h3>Raw Html</h3>
    <p v-html="rawHtml" />
    <h3>Attributes</h3>
    <p v-bind:id="'test1'">
      Mustaches cannot be used inside HTML attributes. Instead, use a v-bind
      directive:
    </p>
    <button type="button" v-bind:disabled="true">Disabled button</button>
    <h3>Directives</h3>
    <a v-bind:href="'https://www.google.com/'">Arguments</a>
    <p v-bind:[attr]="'https://www.google.com/'">Dynamic Arguments</p>
    <h3>Computed and Watcher</h3>
    <p>Has published books:</p>
    <span>{{ author.books.length > 0 ? "Yes" : "No" }}</span>
    <br />
    <span>{{ hasPublishedBooks }}</span>
    <br />
    <span>{{ fullName }}</span>
    <br />
    <InputBox type="xx" />
    <br />
    <ChangeTheme
      text="Change theme"
      :theme="themeColor"
      @change-theme="onHandleThemeChange"
    />
    <br />
    <SlotButtonTest>
      <h1>ABC</h1>
    </SlotButtonTest>
  </div>
</template>
<script>
import InputBox from "../components/InputBox";
import ChangeTheme from "../components/ChangeTheme";
import SlotButtonTest from "../components/SlotButtonTest";

export default {
  name: "Interpolation",
  components: {
    InputBox,
    ChangeTheme,
    SlotButtonTest,
  },
  data() {
    return {
      message: "Interpolatiuon message",
      rawHtml: "This is <small>raw</small> HTML",
      attr: "title",
      firstName: "Gyan",
      lastName: "Mishra",
      author: {
        name: "John Doe",
        books: [
          "Vue 2 - Advanced Guide",
          "Vue 3 - Basic Guide",
          "Vue 4 - The Mystery",
        ],
      },
      themeColor: "#FFFFFF",
      fontColor: "#000000",
    };
  },
  computed: {
    hasPublishedBooks() {
      return this.author.books.length ? "Yes" : "No";
    },
    fullName: {
      get() {
        return `${this.firstName} ${this.lastName}`;
      },
      set(newVal) {
        const names = newVal.split(" ");
        this.firstName = names[0];
        this.lastName = names[names.length - 1];
      },
    },
  },
  watch: {
    firstName(newVal, oldVal) {
      console.log("newVal1 > ", newVal);
      console.log("oldVal1 >", oldVal);
    },
    "author.books": {
      deep: true,
      handler(newVal, oldVal) {
        console.log("newVal > ", newVal);
        console.log("oldVal >", oldVal);
      },
    },
  },
  methods: {
    changeInterpolation() {
      this.message = "Changed Interpolatiuon message";
      this.fullName = "Jhon Doe";
      this.author.books.push("Vue 4 - The Test");
      console.log("****", this.author.books);
    },
    onHandleThemeChange(value) {
      this.themeColor = value.themeColor;
      this.fontColor = value.fontColor;
    },
  },
};
</script>
