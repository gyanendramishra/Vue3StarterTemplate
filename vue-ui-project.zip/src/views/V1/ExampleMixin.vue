<template>
  <button v-on:click="onEncrease">Increase</button>
  counter ({{ counter }})
  <button v-on:click="onDecrease">Decrease</button>
  <SlotButtonTest>Button</SlotButtonTest>
</template>
<script>
import SlotButtonTest from "../components/SlotButtonTest";
import ExampleMixin from "../mixins/example-mixin";
export default {
  name: "ExampleMixin",
  mixins: [ExampleMixin],
  components: {
    SlotButtonTest,
  },
  data() {
    return {
      counter: 10,
    };
  },
  provide() {
    return {
      otherCount: this.counter,
    };
  },
  methods: {
    /*onEncrease() {
      console.log("component: On Encrease");
      //this.counter += 1;
    },
    onDecrease() {
      console.log("component: On decrease");
      //this.counter -= 1;
    },*/
  },
  beforeCreate() {
    console.log("Component: before create");
  },
  created() {
    console.log("Component: created");
  },
  beforeMount() {
    console.log("Component: before mount");
  },
  mounted() {
    console.log("Component: mounted");
  },
  beforeUpdate() {
    console.log("Component: before update");
  },
  updated() {
    console.log("Component: updated");
  },
  beforeUnmount() {
    console.log("Component: before destroy");
  },
  unmounted() {
    console.log("Component: destroyed");
  },
};
</script>
