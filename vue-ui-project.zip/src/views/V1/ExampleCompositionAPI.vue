<template>
  <h1>Composition Api</h1>
  <p>
    My name is {{ name }} and my age is {{ age }} and name 2 is {{ nameTwo }}
  </p>
  <button @click="handleClick">Change Info</button>
</template>
<script>
import { ref } from "vue";
export default {
  name: "ExampleCompositionApi",
  setup() {
    let name = ref("Gyanendra Mishra");
    let age = ref(30);
    const handleClick = () => {
      name.value = "Gyan";
      age.value = 40;
    };
    return {
      name,
      age,
      handleClick,
    };
  },
  data() {
    return {
      nameTwo: "Gyanendra",
    };
  },
};
</script>
