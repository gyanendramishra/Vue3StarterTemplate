<template>
  <BaseLayout>
    <template #default>
      <ul>
        <li v-for="(item, index) in items" :key="index">
          {{ item.name }}
        </li>
      </ul>
      <Form
        @submit="onSubmit"
        :validation-schema="validationSchema"
        :initial-values="initialValues"
      >
        <Field name="full_name" :validateOnBlur="false" />
        <ErrorMessage name="full_name" />
        <br />
        <Field name="email" />
        <ErrorMessage name="email" />
        <br />
        <SlotButton>Submit({{ initialValues.full_name }})</SlotButton>
      </Form>
    </template>
  </BaseLayout>
</template>
<script>
import BaseLayout from "../layouts/BaseLayout";
import SlotButton from "../components/SlotButton";
import { Form, Field, ErrorMessage, configure } from "vee-validate";
import * as yup from "yup";

// Default values
configure({
  validateOnBlur: true, // controls if `blur` events should trigger validation with `handleChange` handler
  validateOnChange: true, // controls if `change` events should trigger validation with `handleChange` handler
  validateOnInput: false, // controls if `input` events should trigger validation with `handleChange` handler
  validateOnModelUpdate: true, // controls if `update:modelValue` events should trigger validation with `handleChange` handler
});

export default {
  name: "ExampleSlot",
  components: {
    BaseLayout,
    Form,
    Field,
    ErrorMessage,
    SlotButton,
  },
  data() {
    return {
      fullNameRules: yup.string().required().min(3).max(10),
      emailRules: yup.string().email(),
      validationSchema: {
        full_name: yup.string().required().min(3).max(10),
        email: yup.string().email(),
      },
      initialValues: {
        full_name: "Gyanendra",
        email: "gyan",
      },
      items: [
        {
          id: 1,
          name: "Apple",
        },
        {
          id: 2,
          name: "Mango",
        },
        {
          id: 3,
          name: "Banana",
        },
        {
          id: 4,
          name: "Orange",
        },
      ],
    };
  },
  methods: {
    isRequired(value) {
      if (value && value.trim()) {
        return true;
      }

      return "This is required";
    },
    onSubmit(values) {
      alert(JSON.stringify(values, null, 2));
    },
  },
};
</script>
