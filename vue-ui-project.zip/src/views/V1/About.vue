<template>
  <div class="about">
    <NotesList />
  </div>
</template>
<script>
import NotesList from "@/components/NotesList";
export default {
  name: "Home",
  components: {
    NotesList,
  },
};
</script>
