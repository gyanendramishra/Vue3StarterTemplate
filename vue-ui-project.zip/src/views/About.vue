<template>
  <div class="about">About us</div>
</template>
<script>
export default {
  name: "About",
};
</script>
