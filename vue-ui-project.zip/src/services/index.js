export * from "./property-service";
