<template>
  <slot></slot>
</template>
<script>
export default {
  name: "AuthLayout",
};
</script>
