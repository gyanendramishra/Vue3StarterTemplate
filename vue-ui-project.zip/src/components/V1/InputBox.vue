<template>
  <input
    :type="type"
    :name="name"
    :placeholder="placeholder"
    class="input-controll"
  />
</template>

<script>
export default {
  name: "InputBox",
  props: {
    type: {
      type: String,
      required: true,
      default: "text",
      validator(value) {
        return ["text", "email", "tel"].includes(value);
      },
    },
    name: String,
    placeholder: String,
  },
};
</script>
