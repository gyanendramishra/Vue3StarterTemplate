<template>
  <ul>
    <li v-for="(property, index) in properties" :key="index" class="card">
      <p>{{ property._source.en.title }}</p>
      <strong>Price:</strong> {{ property._source.en.currencyType }}
      {{ property._source.attribute.salePrice }}
    </li>
  </ul>
</template>

<script>
import { computed } from "vue";
import { useStore } from "vuex";
export default {
  name: "Iproperties",
  async setup() {
    const store = useStore();
    const properties = computed(() => store.state.home.iProperties);

    await store.dispatch("home/getIProperties");

    return {
      properties,
    };
  },
};
</script>
<style>
.card {
  display: block;
  width: 30%;
  min-height: 100px;
  margin: 3%;
}
</style>
