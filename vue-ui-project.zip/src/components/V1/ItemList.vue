<template>
  <i class="fas fa-check"></i>
  <span class="green">{{ item }}</span>
</template>

<script>
export default {
  name: "ItemList",
};
</script>
