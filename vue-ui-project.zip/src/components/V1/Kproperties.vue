<template>
  <div v-for="(property, index) in properties" :key="index" class="card">
    <p>{{ property._source.en.title }}</p>
    <strong>Price:</strong> {{ property._source.en.currencyType }}
    {{ property._source.attribute.salePrice }}
  </div>
</template>

<script>
import { computed } from "vue";
import { useStore } from "vuex";

export default {
  name: "Kproperties",
  async setup() {
    const store = useStore();

    const properties = computed(() => store.state.home.kProperties);

    await store.dispatch("home/getKProperties");

    return {
      properties,
    };
  },
};
</script>
<style>
.card {
  text-align: center;
  width: 30%;
  min-height: 100px;
  margin: auto 0px;
}
</style>
