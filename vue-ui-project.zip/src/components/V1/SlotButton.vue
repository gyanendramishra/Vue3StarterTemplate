<template>
  <button>
    <slot>Slot Button</slot>
  </button>
</template>
<script>
export default {
  name: "SlotButton",
};
</script>
