<template>
  <div class="hello">
    <ul>
      <li v-for="(note, index) in $store.state.notes" :key="index">
        {{ note }}
        <button type="button" @click="handleNoteDelete(note)">X</button>
      </li>
    </ul>
  </div>
</template>

<script>
import { computed } from "vue";
import { useStore } from "vuex";
export default {
  name: "NotesList",
  setup() {
    const store = useStore();

    const notes = computed(() => store.state.notes);

    /* Handle note save */
    const handleNoteDelete = (note) => {
      store.dispatch("deleteNote", note);
    };

    // return properties and methods
    return {
      notes,
      handleNoteDelete,
    };
  },
};
</script>
