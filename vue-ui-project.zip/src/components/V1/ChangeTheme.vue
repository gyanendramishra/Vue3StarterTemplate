<template>
  <button type="button" @click="handleThemeChange">{{ text }}</button>
</template>

<script>
export default {
  name: "ChangeTheme",
  props: {
    text: String,
    theme: String,
  },
  emits: {
    changeTheme: (value) => {
      if (value.themeColor && value.fontColor) {
        console.log("****", value.fontColor);
        return true;
      } else {
        return false;
      }
    },
  },
  methods: {
    handleThemeChange() {
      const themeColor = this.theme === "red" ? "#FFFFFF" : "red";
      const fontColor = this.theme === "red" ? "#000000" : "white";
      this.$emit("changeTheme", {
        themeColor: themeColor,
        fontColor: fontColor,
      });
    },
  },
};
</script>
