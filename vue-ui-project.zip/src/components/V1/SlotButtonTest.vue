<template>
  <button>
    <small>Slot header {{ otherCount }}</small>
    <slot>Test</slot>
  </button>
</template>

<script>
export default {
  name: "SlotButtonTest",
  inject: ["otherCount"],
};
</script>
