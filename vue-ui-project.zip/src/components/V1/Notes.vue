<template>
  <div class="hello">
    <h1>{{ $store.state.title }}</h1>
    <input v-model="note" @keypress.enter="handleNoteSave" />
  </div>
</template>

<script>
import { ref } from "vue";
import { useStore } from "vuex";
export default {
  name: "Note",
  setup() {
    const store = useStore();
    const note = ref("");

    /* Handle note save */
    const handleNoteSave = () => {
      store.dispatch("saveNote", note.value);
      note.value = "";
    };
    /* Handle note save */
    const handleNoteDelete = (note) => {
      store.dispatch("deleteNote", note);
    };
    // return properties and methods
    return {
      note,
      handleNoteSave,
      handleNoteDelete,
    };
  },
};
</script>
